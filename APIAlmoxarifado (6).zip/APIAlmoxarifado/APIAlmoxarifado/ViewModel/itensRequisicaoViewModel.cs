﻿using APIAlmoxarifado.Models;

namespace APIAlmoxarifado.ViewModel
{
    public class itensRequisicaoViewModel
    {
        public int CodigoProduto { get; set; }
        public double Preco { get; set; }
        public int Quantidade { get; set; }
    }
}
