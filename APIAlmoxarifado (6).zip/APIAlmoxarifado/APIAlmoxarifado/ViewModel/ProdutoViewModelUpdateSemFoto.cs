﻿namespace APIAlmoxarifado.ViewModel
{
    public class ProdutoViewModelUpdateSemFoto
    {       
            public int id { get; set; }
            public string nome { get; set; }
            public int estoque { get; set; }
      
    }
}
