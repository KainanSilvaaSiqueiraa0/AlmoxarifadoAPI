﻿using APIAlmoxarifado.Models;

namespace APIAlmoxarifado.ViewModel
{
    public class RequisicaoViewModel
    {

        public DateTime DataRequisicao { get; set; }

        public List<itensRequisicaoViewModel> itens { get; set; }
    }
}
