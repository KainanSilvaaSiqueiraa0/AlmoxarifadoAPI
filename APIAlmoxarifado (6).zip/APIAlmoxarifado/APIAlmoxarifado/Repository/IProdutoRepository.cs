﻿using APIAlmoxarifado.Models;

namespace APIAlmoxarifado.Repository
{
    public interface IProdutoRepository
    {
        List<Produto> GetAll();

        void Add(Produto produto);

        void Update(Produto produto);
    }
}
