﻿using APIAlmoxarifado.Infraestrutura;
using APIAlmoxarifado.Models;

namespace APIAlmoxarifado.Repository
{
    public class RequisicaoRepository
    {
        ConexaoSQL bdConexao = new ConexaoSQL();

        public void Add(Requisicao requisicao)
        {
            bdConexao.Add(requisicao);            
            bdConexao.SaveChanges();
        }

     
    }
}
