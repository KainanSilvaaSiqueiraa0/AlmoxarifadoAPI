﻿namespace APIAlmoxarifado.Models
{
    public class Departamento
    {
        public int Codigo { get; set; }

        public string Descricao { get; set; }
    }
}
