﻿namespace APIAlmoxarifado.Models
{
    public class Funcionario
    {
        public int Codigo { get; set; }

        public string Nome { get; set; }
    }
}
