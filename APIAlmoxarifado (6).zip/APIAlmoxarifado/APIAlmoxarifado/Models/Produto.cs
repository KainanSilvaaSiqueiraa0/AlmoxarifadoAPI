﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace APIAlmoxarifado.Models
{
    public class Produto
    {
       
        public int id { get; set; }
        public string nome { get; set; }
        public int  estoque { get; set; }
        public string? photourl { get; set; }

        public List<itensRequisicao> itens { get; set; }



    }
}
