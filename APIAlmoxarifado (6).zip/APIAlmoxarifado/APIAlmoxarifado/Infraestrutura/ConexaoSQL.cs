﻿using APIAlmoxarifado.Models;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Metadata;

namespace APIAlmoxarifado.Infraestrutura
{
    public class ConexaoSQL : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
           =>
             optionBuilder.UseSqlServer(
                 @"Server=.\SENAI;" +
                 "Database=dbAlmoxarifado;" +
                 "User id=sa;" +
                 "Password=senai.123"
             );

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Requisicao>()
                .HasMany(e => e.itens)
                .WithOne(e => e.Requisicao)
                .HasForeignKey(e => e.CodigoRequisicao)
                .HasPrincipalKey(e => e.Codigo);


            modelBuilder.Entity<Produto>()
              .HasMany(e => e.itens)
              .WithOne(e => e.Produto)
              .HasForeignKey(e => e.CodigoProduto)
              .HasPrincipalKey(e => e.id);
        }

        public DbSet<Produto> Produto { get; set; }
        public DbSet<Requisicao> Requisicao{ get; set; }

        public DbSet<itensRequisicao> ItensRequisicao { get; set; }
    }
}
